/*****************************************************************
* Nome: Marcos Cavalcante Barboza								 *
* R.A.: 408.336													 *
* Objetivo: elaborar um programa que processe fichas cadastrais  *
*		  de pacientes, realizando operacoes de busca,inserção,	 *
*		  exclusão e etc...										 *
******************************************************************/

//bibliotecas utilizadas pelo programa
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pacientes.h"

//funcao principal
int main(){
int opc, total = 0;
Paciente *dados;

dados = Carregar_Dados(&total);

do{
	menu();
	scanf("%d",&opc);
		switch(opc){
			case 1:
				Incluir(dados,&total);	break;
			case 2:
				Alterar(total,dados);	break;
			case 3:
				Consultar(total,dados);	break;
			case 4:
				Excluir(&total,dados);	break;
			case 5:
				Listar(dados,total);	break;
			case 6:
				printf("Sair \n");
			default: 
				printf("numero invalido \n");
	
		}
}while(opc != 6);

Salvar_Dados(dados,&total);

return 0;
}

