#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "pacientes.h"

//escreve os dados de um paciente na struct, tendo como entrada, informaçoes enviadas pelo usuario
void Editar_Paciente(Paciente *new){
	
	printf("Informe o codigo: \n");
	scanf("%d",&new->codigo);
	getchar();
	printf("Informe o nome: \n");
	scanf("%25[^\n]",new->nome);
	printf("Informe o sobrenome: \n");
	getchar();
	scanf("%45[^\n]",new->sobrenome);
	printf("Informe a data de nascimento: \n");
	scanf("%d %d %d",&new->data_nasc.dia,&new->data_nasc.mes,&new->data_nasc.ano);
	printf("Informe o peso: \n");	
	scanf("%f",&new->peso);

}

//funcao que exibe as opcoes do menu na tela
void menu(void){

	printf("Escolha uma das 6 opções: \n");
	printf("1- Incluir \n");
	printf("2- Alterar \n");
	printf("3- Consultar \n");
	printf("4- Excluir \n");
	printf("5- Listar \n");
	printf("6- Sair \n");

}

//funcao que pergunta ao usuario qual o codigo que ele deseja alterar
int question(void){
int cod=0;

	printf("Qual código deseja alterar/consultar/excluir ? \n");
	scanf("%d",&cod);

return cod;
}


/************************************************************************
* Esta funcao inclui mais um paciente no cadastro, tomando o cuidado	*
* de inicialmente ver se o vetor ja foi alocado, se ja foi, entao ele   *
* realoca esse vetor													*
*************************************************************************/
void Incluir(Paciente *pac,int *total){
	if(pac == NULL){
		pac = (Paciente *) malloc(sizeof(Paciente));
		Editar_Paciente(pac);	
		*total++;
	}else{
		pac = (Paciente *) realloc(pac, (*total+1) * sizeof(Paciente));
		Editar_Paciente(&pac[*total-1]);
		*total++;
	}	
}


/****************************************************************************************
* esta funcao altera os dados de um paciente, ela realiza o seguinte procedimento,		*
* recebe o codigo a ser buscado e ve se é um codigo valido, se for a alteracao é feita,	*
* realizando a alteracao																*
*****************************************************************************************/
void Alterar(int total,Paciente *pac){
int code = 0,n;
Paciente aux;
	Paciente teste;
	n = question();
	code = buscar_paciente(pac,n,total);	
	if (code == -1){	
		printf("codigo nao encontrado \n");	
	}else{
		 Editar_Paciente(&pac[code]);		
	}		
}

/********************************************************************************************
* esta funcao consulta os dados de um paciente, ela realiza o seguinte procedimento,		*
* recebe o codigo a ser consultado e ve se é um codigo valido, se for a impressao da ficha  *
* é feita																					*
*********************************************************************************************/
void Consultar(int total,Paciente *pac){
int code = 0;
		
	code = question();

	code = buscar_paciente(pac,code,total);
	printf("O valor de code: %d",code);

		if (code != -1){
			Imprimir(pac[code]);
		}else{ 
			printf("codigo nao encontrado \n");
		}		

}

/***************************************************************************
* esta funcao realiza a exclusao de um determinado paciente da struct,	   *
* realocando novamente o vetor.											   *
****************************************************************************/
void Excluir(int *total,Paciente *pac){
int code = 0;
	code = question();
	code = buscar_paciente(pac,code,*total);
	if ((code > 0) && (code <= *total)){
			if(*total == 1){
				free(pac);
			}else{
				trocar_paciente(&pac[code],&pac[*total-1]);		
				pac = realloc(pac,(*total-1)*(sizeof(Paciente)));				
			}	
	}else{ 
			printf("codigo nao encontrado \n");
			}
	*total = *total - 1;
}


//essa funcao realiza a listagem dos pacientes de acordo com o tipo de ordenacao solicitada
void Listar(Paciente *pac,int total){
int opc=0,i;
	printf("Qual o tipo de ordenacao desejado?: Por: Codigo[1] ou Nome[2]");
	scanf("%d",&opc);
	if(opc == 1){
		Ordenar_Paciente_Codigo(total,pac);
	}else if(opc == 2){
		Ordenar_Paciente_Nome(pac,total);	
	}else{
		printf("Opcao invalida!!!!");
	}

	for(i=0;i<total;i++){
		Imprimir(pac[i]);
	}

}


//funcao Carregar dados, ela abrira o arquivo para leitura dos registros
Paciente *Carregar_Dados(int *quant){
int i=0;
FILE *text;
Paciente *pessoa;

text = fopen("dados.bin","rb");

if(text == NULL){
	perror("Não foi possível abrir o arquivo \n");
	exit(-1);
}

fread(quant,sizeof(int),1,text);

pessoa = (Paciente *) malloc((*quant) * sizeof(Paciente));

if(pessoa == NULL){
	printf("Nao conseguiu alocar memoria \n");
	exit(1);
}

for(i=0;i < (*quant);i++){
	fread(&pessoa[i],sizeof(Paciente),1,text);
}

fclose(text);

return pessoa;
}


//A funcao Salvar Dados grava os dados armazenados no vetor de structs no arquivo binario.
void Salvar_Dados(Paciente *pac,int *total){
int i=0;
FILE *arq;	

arq = fopen("dados.bin","wb");
fwrite(&total,sizeof(int),1,arq);
	
	for(i=0;i < *total;i++){
		fwrite(&pac[i],sizeof(Paciente),1,arq);
	}

fclose(arq);
}


//ordenacao dos pacientes por codigo, o metodo de ordenacao utilizado é o bubble sort
void Ordenar_Paciente_Codigo(int total,Paciente *pac){
int count=0,k=0,bubble=0;
Paciente auxiliar;

count = total-2;

while(count > 0){
	bubble=0;
	for(k=0;k < count;k++){
		if (pac[k].codigo >  pac[k+1].codigo){
			auxiliar = pac[k];
			pac[k] = pac[k + 1];
			pac[k + 1] = auxiliar;
			bubble = k;
		}
	}
count = bubble;
}

}



//essa funcao compara duas strings, e ordena a struct por nome
void Ordenar_Paciente_Nome(Paciente *pac,int total){
int i,k;
Paciente aux;

		for(k=0;k<total;k++){
			for(i=0;i<total-1;i++){
				if(strcmp(pac[i].nome, pac[i+1].nome)>0){
					aux = pac[i];
					pac[i] = pac[i+1];
					pac[i+1]=aux;				
				}
				else if(strcmp(pac[i].nome, pac[i+1].nome) == 0){
					if(strcmp(pac[i].sobrenome, pac[i+1].sobrenome)>0){
						aux = pac[i];
						pac[i] = pac[i+1];
						pac[i+1]=aux;				
					}					
				}
			}
		}
}



//imprimir os dados do paciente
void Imprimir(Paciente imprimir_pac){
	
	printf("Codigo: %d \n",imprimir_pac.codigo);
	printf("Nome: %s \n",imprimir_pac.nome);
	printf("Sobrenome: %s \n",imprimir_pac.sobrenome);
	printf("Data de nascimento: %d/%d/%d \n",imprimir_pac.data_nasc.dia,imprimir_pac.data_nasc.mes,imprimir_pac.data_nasc.ano);
	printf("Peso: %f \n",imprimir_pac.peso);

}


//procurar no vetor e retornar um ponteito ou o  indice
int buscar_paciente(Paciente *pac,int code,int total){
int i = 0,flag = -1;
		
	for(i = 0;i < total;i++){
		if(pac[i].codigo == code){
			flag = i;	
		}
	}

return flag;
}


//troca o conteudo de duas structs, utilizando uma struct auxiliar
void trocar_paciente(Paciente *pri, Paciente *seg){
Paciente *aux;
	
		*aux = *pri;
		*pri = *seg;
		*seg = *aux;

}
