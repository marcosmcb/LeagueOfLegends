
typedef struct Data{
	int dia;
	int mes;
	int ano;
}Data;

//struct Paciente
typedef struct Paciente{
	int codigo;
	char nome[25];
	char sobrenome[45];
	float peso;
	Data data_nasc;	
}Paciente;

//funcoes auxiliares
void Editar_Paciente(Paciente *new);
void Imprimir(Paciente imprimir_pac);
int buscar_paciente(Paciente *pac,int code,int total);
void trocar_paciente(Paciente *pri,Paciente *seg);
void Ordenar_Paciente_Codigo(int total,Paciente *pac);
void Ordenar_Paciente_Nome(Paciente *pac,int total);
int question(void);

//funcoes principais
void Incluir(Paciente *pac,int *total);
void Alterar(int total,Paciente *pac);
void Consultar(int total,Paciente *pac);
void Excluir(int *total,Paciente *pac);
void Listar(Paciente *pac,int total);
Paciente *Carregar_Dados();
void Salvar_Dados(Paciente *pac,int *total);
void menu(void);
